<?php

namespace Drupal\uniqletts_api\Controller;

use Drupal\Core\Controller\ControllerBase;

use Drupal\node\Entity\Node;
use Drupal\file\Entity\File;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Class PropertyAPIController.
 */
class PropertyAPIController extends ControllerBase {

  /**
   * GET Method.
   *
   * @return json
   *   Return Get string.
   */
  public function get(Request $request, $type, $nid = -1) {

    if($nid == -1) {
      $query = \Drupal::entityQuery('node')
      ->condition('status', 1)
      ->condition('type', 'property')
      ->condition('field_property_type', $type);
    } else {
      $query = \Drupal::entityQuery('node')
      ->condition('status', 1)
      ->condition('nid', $nid)
      ->condition('type', 'property')
      ->condition('field_property_type', $type);
    }

    $nids = $query->execute();

    $nodes =  \Drupal\node\Entity\Node::loadMultiple($nids);

    $properties = array();

    foreach ($nodes as $n) {

      $fids = $n->get('field_image')->getValue();

      $images = array();

      foreach ($fids as $key => $value) {
          $file = \Drupal\file\Entity\File::load($value['target_id']);
          $image_url = file_create_url($file->getFileUri());
          array_push($images, $image_url);
      }



      $property = array(
        'title' => $n->getTitle(),
        'short_description' => $n->get('field_short_description')->getValue()[0]['value'],
        'images' => $images,
        'price' => $n->get('field_price_ps_')->getValue()[0]['value'],
        'price_type' => $n->get('field_price_type')->getValue()[0]['value']
      );
      array_push($properties, $property);
    }
    $response['data'] = $properties;
    $response['method'] = 'GET';

    return new JsonResponse( $response );
  }

}
