<?php

namespace Drupal\uniqletts_api\Controller;

use Drupal\Core\Controller\ControllerBase;

use Drupal\node\Entity\Node;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Class APIController.
 */
class PageAPIController extends ControllerBase {

  /**
   * GET Method.
   *
   * @return string
   *   Return Get string.
   */
  public function get(Request $request) {

    if($request->query->get('page') != null && $request->query->get('page') == 'home') {
      $query = \Drupal::entityQuery('node')
      ->condition('status', 1)
      ->condition('type', 'slide');

      $slide_nids = $query->execute();

      $slide_nodes =  \Drupal\node\Entity\Node::loadMultiple($slide_nids);

      $slides = array();

      foreach ($slide_nodes as $n) {

        $file = \Drupal\file\Entity\File::load($n->get('field_image')->getValue()[0]['target_id']);
        $image_url = file_create_url($file->getFileUri());

        $slide = array(
          'title' => $n->getTitle(),
          'button' => array(
            'label' => $n->get('field_button_link')->getValue()[0]['title'],
            'uri' => $n->get('field_button_link')->getValue()[0]['uri']
          ),
          'image' =>  $image_url
        );
        array_push($slides, $slide);
      }
      $banner = "With over 120 years experience, we offer a high quality and trustworthy service for properties in your area.";

      $query = \Drupal::entityQuery('node')
      ->condition('status', 1)
      ->condition('type', 'property')
      ->condition('field_featured', 1);

      $property_nids = $query->execute();

      $property_nodes =  \Drupal\node\Entity\Node::loadMultiple($property_nids);

      $features = array();
      $features['sales'] = array();
      $features['lettings'] = array();

      foreach ($property_nodes as $n) {

        $file = \Drupal\file\Entity\File::load($n->get('field_image')->getValue()[0]['target_id']);
        $image_url = file_create_url($file->getFileUri());

        $property = array(
          'id' => 0,
          'title' => $n->getTitle(),
          'short_description' => $n->get('field_short_description')->getValue()[0]['value'],
          'image' => $image_url,
          'price' =>  $n->get('field_price_ps_')->getValue()[0]['value'],
          'price_type' =>  $n->get('field_price_type')->getValue()[0]['value'],
          'property_type' =>  $n->get('field_property_type')->getValue()[0]['value']
        );
        if($property['property_type'] == 'Sales') {
          array_push($features['sales'], $property);
        } else if($property['property_type'] == 'Lettings') {
          array_push($features['lettings'], $property);
        }

      }
      $data = array(
        'slides' => $slides,
        'banner' => $banner,
        'features' => $features
      );
    } else if($request->query->get('id') != null) {
      // Return page object
      $nid = intval($request->query->get('id'));

      $node = \Drupal\node\Entity\Node::load($nid);

      $data = array(
        'title' => $node->getTitle(),
        'html' => $node->get('body')->getValue()[0]['value']
      );
    }

    $response['data'] = $data;
    $response['method'] = 'GET';

    return new JsonResponse( $response );
  }

}
