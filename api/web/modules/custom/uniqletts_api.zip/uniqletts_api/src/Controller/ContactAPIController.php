<?php

namespace Drupal\uniqletts_api\Controller;

use Drupal\Core\Controller\ControllerBase;

use Drupal\node\Entity\Node;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Class APIController.
 */
class ContactAPIController extends ControllerBase {

  /**
   * POST Method.
   *
   * @return json
   *   Return Post string.
   */
  public function post(Request $request) {
    // Create a new contact record and send an email notification
    $data = array(
      'type' => 'contact',
      'title' => 'Contact Submission -'.date('d/m/Y h:i:s', strtotime(time())),
      'field_contacttype' => 'Contact Message',
      'field_firstname' => $request->request->get('contact_firstname'),
      'field_lastname' => $request->request->get('contact_lastname'),
      'field_email' => $request->request->get('contact_email'),
      'field_contact' => $request->request->get('contact_contact'),
      'field_message' => $request->request->get('contact_message')
    );

    $node = Node::create($data);
    $node->save();

    $response['data'] = $node;
    $response['method'] = 'POST';

    return new JsonResponse( $response );
  }

}
